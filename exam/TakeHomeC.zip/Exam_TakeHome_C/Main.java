import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    static int FindSadFeeling(List<Integer> arr, int start) {
        for (int i = start; i < arr.size(); i++) {
            if (arr.get(i) == -1) {
                return i;
            }
        }
        return -1;
    }

    static boolean CheckNeighbours(List<Integer> arr, int pos) {
        if(arr.get(pos) != -1) {
            return false;
        }

        if (pos < 0 || pos >= arr.size()) {
            return false;
        }

        if (pos == 0 || pos == arr.size() - 1) {
            return true;
        }

        return arr.get(pos - 1) != 1 || arr.get(pos + 1) != 1;
    }

    static List<Integer> InsertHappyFeelings(List<Integer> arr, int pos) {
        if (pos < 0 || pos >= arr.size()) {
            return arr;
        }
        if (arr.get(pos) != -1) {
            return arr;
        }
        if (pos == 0 || arr.get(pos - 1) != 1) {
            arr.add(pos, 1);
            pos = pos + 1;
        }
        if (pos == arr.size() || pos == arr.size()-1 || arr.get(pos + 1) != 1) {
            arr.add(pos + 1, 1);
        }
        return arr;
    }

    static List<Integer> BeHappy(List<Integer> arr) {
        int i = 0;
        while ((i = FindSadFeeling(arr, i))  != -1) {
            if (CheckNeighbours(arr, i)) {
                arr = InsertHappyFeelings(arr, i);
            }

            i = i+1;
        }
        return arr;
    }

    public static void main(String[] args) {
        List<Integer> arr = Arrays.asList(-1,-1,0,0,1,1,-1,1,0,-1,1,0,1,1,-1, 0,1,1);
        ArrayList<Integer> arrList = new ArrayList<>(arr);
        System.out.println(BeHappy(arrList));
    }
}

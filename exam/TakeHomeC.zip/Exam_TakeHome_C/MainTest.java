
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertThrows;

public class MainTest {

    @Test
    public void testFindSadFeeling() {
        ArrayList<Integer> arr1 = new ArrayList<>(Arrays.asList(-1,0,1));
        assertEquals(0, Main.FindSadFeeling(arr1, 0));

        ArrayList<Integer> arr2 = new ArrayList<>(Arrays.asList(1,0,1));
        assertEquals(-1, Main.FindSadFeeling(arr2, 0));

        ArrayList<Integer> arr3 = new ArrayList<>(Arrays.asList(1,0,-1));
        assertEquals(2, Main.FindSadFeeling(arr3, 0));

        ArrayList<Integer> arr4 = new ArrayList<>(Arrays.asList(1,0,-1));
        assertEquals(-1, Main.FindSadFeeling(arr4, 3));

        ArrayList<Integer> arr5 = new ArrayList<>(Arrays.asList(1,0,-1));
        assertThrows(IndexOutOfBoundsException.class, () -> Main.FindSadFeeling(arr5, -1));
    }

    @Test
    public void testCheckNeighbours() {
        ArrayList<Integer> arr1 = new ArrayList<>(Arrays.asList(-1,0,1));
        assertTrue(Main.CheckNeighbours(arr1, 0));
        assertFalse(Main.CheckNeighbours(arr1, 1));
        assertFalse(Main.CheckNeighbours(arr1, 2));

        ArrayList<Integer> arr2 = new ArrayList<>(Arrays.asList(1,-1,1));
        assertFalse(Main.CheckNeighbours(arr2, 1));

        ArrayList<Integer> arr3 = new ArrayList<>(Arrays.asList(1,0,-1));
        assertTrue(Main.CheckNeighbours(arr3, 2));

        assertThrows(IndexOutOfBoundsException.class, () -> Main.CheckNeighbours(arr3, 3));
        assertThrows(IndexOutOfBoundsException.class, () -> Main.CheckNeighbours(arr3, -1));
    }

    @Test
    public void testBeHappy() {
        ArrayList<Integer> arr1 = new ArrayList<>(Arrays.asList(-1,-1,0,0,1,1,-1,1,0,-1,1,0,1,1,-1, 0,1,1));
        assertEquals(Arrays.asList(1,-1,1,-1,1,0,0,1,1,-1,1,0,1,-1,1,0,1,1,-1,1,0,1,1), Main.BeHappy(arr1));

        ArrayList<Integer> arr2 = new ArrayList<>(Arrays.asList(1,1,1));
        assertEquals(Arrays.asList(1,1,1), Main.BeHappy(arr2));

        ArrayList<Integer> arr3 = new ArrayList<>(List.of(-1));
        assertEquals(Arrays.asList(1,-1,1), Main.BeHappy(arr3));

        ArrayList<Integer> arr4 = new ArrayList<>(Arrays.asList(0,0,0));
        assertEquals(Arrays.asList(0,0,0), Main.BeHappy(arr4));
    }
}
package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import org.example.pages.DictionaryPage;
import org.example.pages.WikihowDictionaryPage;
import org.openqa.selenium.WebDriver;

import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getDriver;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.not;

public class WikihowEndUserSteps {

    WikihowDictionaryPage dictionaryPage;

    @Step
    public void enters(String keyword) {
        dictionaryPage.enter_keywords(keyword);
    }

    @Step
    public void starts_search() {
        dictionaryPage.lookup_terms();
    }

    @Step
    public void should_see_title(String title) {
        assertThat(dictionaryPage.getArticlesTitle(), hasItem(containsString(title)));
    }

    @Step
    public void should_not_see_title(String title) {
        assertThat(dictionaryPage.getArticlesTitle(), not(hasItem(containsString(title))));
    }

    @Step
    public void is_the_home_page() {
        dictionaryPage.open();
    }

    @Step
    public void looks_for(String term) {
        enters(term);
        starts_search();
    }

    @Step
    public void entersMail(String mail) {
        dictionaryPage.enter_mail(mail);
    }

    @Step
    public void starts_subscription() {
        dictionaryPage.subscribe_to_newsletter();
    }

    @Step
    public void subscribes_to_newsletter(String mail) {
        entersMail(mail);
        starts_subscription();
    }

    @Step
    public void should_subscribe() {
        WebDriver driver = getDriver();
        String currentUrl = driver.getCurrentUrl();
        System.out.println(currentUrl);
        assertThat(currentUrl, equalTo("https://www.wikihow.com/Newsletters?sub=wh&email=alice_hincu%40yahoo.com"));
    }

    @Step
    public void should_not_subscribe() {
        WebDriver driver = getDriver();
        String currentUrl = driver.getCurrentUrl();
        System.out.println(currentUrl);
        assertThat(currentUrl, equalTo("https://www.wikihow.com/Main-Page"));
    }
}
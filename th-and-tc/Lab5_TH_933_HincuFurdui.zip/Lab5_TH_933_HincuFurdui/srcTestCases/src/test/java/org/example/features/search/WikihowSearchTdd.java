//package org.example.features.search;
//
//import net.serenitybdd.junit.runners.SerenityRunner;
//import net.thucydides.core.annotations.Issue;
//import net.thucydides.core.annotations.Managed;
//import net.thucydides.core.annotations.Pending;
//import net.thucydides.core.annotations.Steps;
//import net.thucydides.junit.annotations.UseTestDataFrom;
//import org.example.steps.serenity.WikihowEndUserSteps;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.openqa.selenium.WebDriver;
//
//@RunWith(SerenityRunner.class)
//@UseTestDataFrom("src/test/resources/WikiTestDataSearch.csv")
//public class WikihowSearchTdd {
//    public String name;
//    public String title;
//
//    @Managed(uniqueSession = true)
//    public WebDriver webdriver;
//
//    @Steps
//    public WikihowEndUserSteps wiki;
//
//    @Issue("#WIKIHOW-1")
//    @Test
//    public void searching_by_keyword_vampire_should_display_the_corresponding_title() {
//        wiki.is_the_home_page();
//        wiki.looks_for("vampire");
//        wiki.should_see_title("How to Look Like a Vampire");
//    }
//
//    @Test
//    public void searching_by_keyword_vampire_should_not_display_the_corresponding_title() {
//        wiki.is_the_home_page();
//        wiki.looks_for("vampire");
//        wiki.should_not_see_title("How to Not Look Like a Vampire");
//    }
//
//    @Issue("#WIKI-2")
//    @Test
//    public void newsletter_subscription_address_good() {
//        wiki.is_the_home_page();
//        wiki.subscribes_to_newsletter("alice_hincu@yahoo.com");
//        wiki.should_subscribe();
//    }
//
//    @Test
//    public void newsletter_subscription_address_wrong() {
//        wiki.is_the_home_page();
//        wiki.subscribes_to_newsletter("alice_hincu");
//        wiki.should_not_subscribe();
//    }
//
//    @Pending @Test
//    public void searching_by_ambiguious_keyword_should_display_the_disambiguation_page() {
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//}
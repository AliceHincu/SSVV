package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.WikihowEndUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/WikiTestDataSignupBad.csv")
public class WikihowSignupBadDDT {
    public String mail;

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public WikihowEndUserSteps wiki;

    @Issue("#WIKI-SIGNUP-BAD")
    @Test
    public void newsletter_subscription_address_good() {
        wiki.is_the_home_page();
        wiki.subscribes_to_newsletter(getMail());
        wiki.should_not_subscribe();
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}
package org.example.pages;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;
import net.serenitybdd.core.pages.WebElementFacade;
import java.util.stream.Collectors;

import net.serenitybdd.core.annotations.findby.FindBy;

import net.thucydides.core.pages.PageObject;

import java.util.List;

@DefaultUrl("https://www.wikihow.com/Main-Page")
public class WikihowDictionaryPage extends PageObject{
    @FindBy(id="hs_query")
    private WebElementFacade searchTerms;

    @FindBy(id="hs_submit")
    private WebElementFacade lookupButton;

    @FindBy(id="hp_newsletter_email")
    private WebElementFacade mailAddressInput;

    @FindBy(id="hp_newsletter_signup")
    private WebElementFacade subscribeButton;

    public void enter_keywords(String keyword) {
        searchTerms.type(keyword);
    }

    public void lookup_terms() {
        lookupButton.click();
    }

    public void enter_mail(String keyword) {
        mailAddressInput.type(keyword);
    }

    public void subscribe_to_newsletter() {
        subscribeButton.click();
    }

    public List<String> getArticlesTitle() {
        return findAll(By.className("result_title")).stream()
                .map(WebElementFacade::getText)
                .collect(Collectors.toList());
    }
}

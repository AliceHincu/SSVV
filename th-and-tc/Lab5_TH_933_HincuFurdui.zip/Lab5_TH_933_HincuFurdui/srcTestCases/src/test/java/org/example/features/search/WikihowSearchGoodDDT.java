package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Pending;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.WikihowEndUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/WikiTestDataSearchGood.csv")
public class WikihowSearchGoodDDT {
    public String name;
    public String title;

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public WikihowEndUserSteps wiki;

    @Issue("#WIKIHOW-GOOD-SEARCH")
    @Test
    public void searching_by_keyword_vampire_should_display_the_corresponding_title() {
        wiki.is_the_home_page();
        wiki.looks_for(getName());
        wiki.should_see_title(getTitle());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
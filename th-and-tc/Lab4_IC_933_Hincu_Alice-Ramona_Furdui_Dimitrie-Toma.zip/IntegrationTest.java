package ssv.example;

import curent.Curent;
import domain.Nota;
import domain.Student;
import domain.Tema;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import repository.NotaXMLRepo;
import repository.StudentXMLRepo;
import repository.TemaXMLRepo;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.ValidationException;
import java.time.LocalDate;

import java.time.temporal.TemporalAmount;
import java.util.Date;
import java.util.function.Consumer;


public class IntegrationTest extends TestCase {
    public IntegrationTest(String testName) {
        super(testName);
    }

    private Service getService() {
        StudentValidator studentValidator = new StudentValidator();
        TemaValidator temaValidator = new TemaValidator();
        String filenameStudent = "fisiere/Studenti.xml";
        String filenameTema = "fisiere/Teme.xml";
        String filenameNota = "fisiere/Note.xml";

        StudentXMLRepo studentXMLRepository = new StudentXMLRepo(filenameStudent);
        TemaXMLRepo temaXMLRepository = new TemaXMLRepo(filenameTema);
        NotaValidator notaValidator = new NotaValidator(studentXMLRepository, temaXMLRepository);
        NotaXMLRepo notaXMLRepository = new NotaXMLRepo(filenameNota);
        return new Service(studentXMLRepository, studentValidator, temaXMLRepository, temaValidator, notaXMLRepository, notaValidator);
    }

    public static Test suite() {
        return new TestSuite(IntegrationTest.class);
    }

    private void assertThrows(Runnable runnable) {
        try {
            runnable.run();
            assert(false);
        } catch (ValidationException e) {
            assert(true);
        } catch (Exception e) {
            assert(false);
        }
    }

    public void testValidStudent() {
        final Service service = getService();
        final Student student = new Student("1", "Andrei", 933, "a@example.com");
        service.addStudent(student);
    }

    public void testValidAssignment() {
        final Tema tema = new Tema("1", "descriere", 5, 4);
        final Service service = getService();
        service.addTema(tema);
    }

    public void testValidGrade() {
        final Nota nota = new Nota("1", "1", "1", 10, Curent.getStartDate().plusDays(14));
        final Service service = getService();
        service.addNota(nota, "feedback");
    }

    public void testAll() {
        final Service service = getService();
        final Student student = new Student("1", "Andrei", 933, "a@example.com");
        final Tema tema = new Tema("1", "descriere", 5, 4);
        final Nota nota = new Nota("1", "1", "1", 10, Curent.getStartDate().plusDays(14));

        service.addStudent(student);
        service.addTema(tema);
        service.addNota(nota, "feedback");
    }
}

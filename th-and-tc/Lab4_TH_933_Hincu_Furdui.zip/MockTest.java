package ssv.example;

import curent.Curent;
import domain.Nota;
import domain.Student;
import domain.Tema;
import junit.framework.TestCase;
import org.mockito.Mockito;
import repository.NotaXMLRepo;
import repository.StudentXMLRepo;
import repository.TemaXMLRepo;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;

import static org.mockito.Mockito.when;

class MockResult {
    final StudentXMLRepo studentXMLRepo;
    final StudentValidator studentValidator;
    final TemaXMLRepo temaXMLRepo;
    final TemaValidator temaValidator;
    final NotaXMLRepo notaXMLRepo;
    final NotaValidator notaValidator;
    final Service service;

    MockResult(
        StudentXMLRepo studentXMLRepo,
        StudentValidator studentValidator,
        TemaXMLRepo temaXMLRepo,
        TemaValidator temaValidator,
        NotaXMLRepo notaXMLRepo,
        NotaValidator notaValidator,
        Service service
    ) {
        this.studentXMLRepo = studentXMLRepo;
        this.studentValidator = studentValidator;
        this.temaXMLRepo = temaXMLRepo;
        this.temaValidator = temaValidator;
        this.notaXMLRepo = notaXMLRepo;
        this.notaValidator = notaValidator;
        this.service = service;
    }
}

public class MockTest extends TestCase {
    public MockTest(String testName) {
        super(testName);
    }

    public MockResult getMocks() {
        final StudentXMLRepo studentXMLRepo = Mockito.mock(StudentXMLRepo.class);
        final StudentValidator studentValidator = Mockito.mock(StudentValidator.class);
        final TemaXMLRepo temaXMLRepo = Mockito.mock(TemaXMLRepo.class);
        final TemaValidator temaValidator = Mockito.mock(TemaValidator.class);
        final NotaXMLRepo notaXMLRepo = Mockito.mock(NotaXMLRepo.class);
        final NotaValidator notaValidator = Mockito.mock(NotaValidator.class);
        final Service service = new Service(studentXMLRepo, studentValidator, temaXMLRepo, temaValidator, notaXMLRepo, notaValidator);
        return new MockResult(studentXMLRepo, studentValidator, temaXMLRepo, temaValidator, notaXMLRepo, notaValidator, service);
    }

    public void testValidStudent() {
        final MockResult mocks = getMocks();
        final Student student = new Student("1", "Andrei", 933, "a@example.com");
        when(mocks.studentXMLRepo.save(student)).thenReturn(student);
        mocks.service.addStudent(student);
    }

    public void testValidAssignment() {
        final MockResult mocks = getMocks();
        final Tema tema = new Tema("1", "descriere", 5, 4);
        when(mocks.temaXMLRepo.save(tema)).thenReturn(tema);
        mocks.service.addTema(tema);
    }

    public void testValidGrade() {
        final MockResult mocks = getMocks();
        final Tema tema = new Tema("1", "descriere", 2, 4);
        final Student student = new Student("1", "Andrei", 933, "a@example.com");
        final Nota nota = new Nota("1", "1", "1", 10, Curent.getStartDate().plusDays(14));
        when(mocks.notaXMLRepo.save(nota)).thenReturn(nota);
        when(mocks.studentXMLRepo.findOne(nota.getIdStudent())).thenReturn(student);
        when(mocks.temaXMLRepo.findOne(nota.getIdTema())).thenReturn(tema);
        mocks.service.addNota(nota, "feedback");
    }
}
